package com.example.nandan.myapplication.setup;

/**
 * Created by nandan on 12/3/16.
 */
public class AppConfig {
    // Server user login url
    public static String URL_SIDVALIDATE = "http://192.168.43.26/project/sid_validate.php";
    public static String URL_PWD = "http://192.168.43.26/project/Login.php";
    public static final String APP_SERVER_URL = "http://192.168.43.26/project/gcm.php?shareRegId=1";
    public static final String APP_Rating_URL = "http://192.168.43.26/project/rating.php?push=1";
    public static final String GOOGLE_PROJECT_ID = "488077065812";
    public static final String MESSAGE_KEY = "message";
}
